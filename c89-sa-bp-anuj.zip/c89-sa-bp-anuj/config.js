export const firebaseConfig = {
apiKey: "AIzaSyBSFSL08-V7AaJPT7ovY_CsEgYYU-YmepM",
  authDomain: "anuj-class85.firebaseapp.com",
  databaseURL: "https://anuj-class85-default-rtdb.firebaseio.com",
  projectId: "anuj-class85",
  storageBucket: "anuj-class85.appspot.com",
  messagingSenderId: "78523707581",
  appId: "1:78523707581:web:9e817c097d7c2a550d47d4"
  };